package nz.co.tumunuiride;

import android.location.Location;

public final class RideEngine {
    private final RideState state = new RideState();
    private Location previous;
    private long startElapsed;
    private double startLat, startLon, endLat, endLon, corridorM, travelledM;
    private boolean nearA, nearB;

    public RideState update(Location loc, long elapsedRealtimeMs) {
        state.speedKmh = loc.hasSpeed() ? Math.max(0, loc.getSpeed() * 3.6) : 0;
        float dA = distance(loc, Corridor.A_LAT, Corridor.A_LON);
        float dB = distance(loc, Corridor.B_LAT, Corridor.B_LON);
        if (state.phase == RideState.Phase.APPROACHING) {
            state.distanceToEntryM = Math.min(dA, dB);
            boolean moving = state.speedKmh >= 8;
            if (moving && previous != null) {
                float oldA = distance(previous, Corridor.A_LAT, Corridor.A_LON);
                float oldB = distance(previous, Corridor.B_LAT, Corridor.B_LON);
                if (dA <= Corridor.ENTRY_RADIUS_M && oldA > dA && dB < oldB) start(true, elapsedRealtimeMs);
                else if (dB <= Corridor.ENTRY_RADIUS_M && oldB > dB && dA < oldA) start(false, elapsedRealtimeMs);
            }
        } else if (state.phase == RideState.Phase.IN_ZONE) {
            state.elapsedMs = Math.max(1, elapsedRealtimeMs - startElapsed);
            state.distanceToExitM = distance(loc, endLat, endLon);
            if (previous != null && loc.getAccuracy() <= 40 && previous.getAccuracy() <= 40) {
                float step = previous.distanceTo(loc);
                if (step < 250) travelledM += step;
            }
            state.progress = Math.min(1, Math.max(travelledM / corridorM, 1 - state.distanceToExitM / corridorM));
            state.averageKmh = (travelledM / (state.elapsedMs / 1000.0)) * 3.6;
            boolean atExit = state.distanceToExitM <= Corridor.EXIT_RADIUS_M;
            if ((atExit && ((nearA && dA > Corridor.EXIT_RADIUS_M) || (nearB && dB > Corridor.EXIT_RADIUS_M)))
                    || state.distanceToExitM > corridorM + 1000) state.phase = RideState.Phase.COMPLETE;
            nearA = dA <= Corridor.EXIT_RADIUS_M; nearB = dB <= Corridor.EXIT_RADIUS_M;
        }
        previous = new Location(loc);
        return state;
    }

    private void start(boolean fromA, long now) {
        startLat = fromA ? Corridor.A_LAT : Corridor.B_LAT; startLon = fromA ? Corridor.A_LON : Corridor.B_LON;
        endLat = fromA ? Corridor.B_LAT : Corridor.A_LAT; endLon = fromA ? Corridor.B_LON : Corridor.A_LON;
        corridorM = distance(startLat, startLon, endLat, endLon);
        state.direction = fromA ? "Camera A → Camera B" : "Camera B → Camera A";
        state.phase = RideState.Phase.IN_ZONE; startElapsed = now; state.averageKmh = 0; travelledM = 0;
    }

    public RideState state() { return state; }
    public void reset() { state.phase = RideState.Phase.APPROACHING; state.direction = "Waiting for corridor"; previous = null; }
    private static float distance(Location from, double lat, double lon) { return distance(from.getLatitude(), from.getLongitude(), lat, lon); }
    private static float distance(double lat1, double lon1, double lat2, double lon2) {
        float[] out = new float[1]; Location.distanceBetween(lat1, lon1, lat2, lon2, out); return out[0];
    }
}

package nz.co.tumunuiride;

import android.Manifest; import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.graphics.Color; import android.os.*; import android.view.*; import android.widget.*; import androidx.core.app.*; import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status,average,current,remaining; private ProgressBar progress;
    private final BroadcastReceiver updates=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){render(i);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);buildUi();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2);
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);else startRide();}
    private void buildUi(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,28,32,24);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(Color.rgb(9,13,16));
        TextView title=t("WORK ROUTE TEST",22,Color.WHITE);root.addView(title);status=t("Waiting for corridor",18,Color.LTGRAY);root.addView(status);
        TextView label=t("SECTION AVERAGE",15,Color.LTGRAY);label.setPadding(0,50,0,0);root.addView(label);average=t("—",104,Color.rgb(73,220,137));root.addView(average);root.addView(t("km/h   •   LIMIT 100",17,Color.LTGRAY));
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(242,183,5)));root.addView(progress,new LinearLayout.LayoutParams(-1,24));
        remaining=t("Monitoring both approaches",18,Color.WHITE);remaining.setPadding(0,24,0,24);root.addView(remaining);current=t("CURRENT  — km/h",24,Color.WHITE);root.addView(current);
        Button reset=new Button(this);reset.setText("RESET RIDE");reset.setOnClickListener(v->startService(new Intent(this,RideService.class).setAction(RideService.ACTION_RESET)));root.addView(reset,new LinearLayout.LayoutParams(-1,-2));
        TextView note=t("Prototype • GPS estimates only\nObey posted and temporary speed limits",14,Color.GRAY);note.setGravity(Gravity.CENTER);note.setPadding(0,28,0,0);root.addView(note);setContentView(root);}
    private TextView t(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setGravity(Gravity.CENTER);return v;}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==1&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startRide();}
    private void startRide(){ContextCompat.startForegroundService(this,new Intent(this,RideService.class));}
    private void render(Intent i){String phase=i.getStringExtra("phase");double s=i.getDoubleExtra("speed",0),a=i.getDoubleExtra("average",0),rem=i.getDoubleExtra("remaining",0),pr=i.getDoubleExtra("progress",0);
        current.setText(String.format(Locale.NZ,"CURRENT  %.0f km/h",s));status.setText(i.getStringExtra("direction"));
        if("IN_ZONE".equals(phase)){average.setText(String.format(Locale.NZ,"%.1f",a));average.setTextColor(a>100?Color.rgb(255,78,78):a>97?Color.rgb(242,183,5):Color.rgb(73,220,137));remaining.setText(String.format(Locale.NZ,"%.1f km remaining",rem/1000));progress.setProgress((int)(pr*1000));}
        else if("COMPLETE".equals(phase)){remaining.setText("Corridor complete");progress.setProgress(1000);}else{average.setText("—");remaining.setText("Monitoring both approaches");progress.setProgress(0);}}
    @Override protected void onStart(){super.onStart();ContextCompat.registerReceiver(this,updates,new IntentFilter(RideService.ACTION_UPDATE),ContextCompat.RECEIVER_NOT_EXPORTED);}
    @Override protected void onStop(){unregisterReceiver(updates);super.onStop();}
}

package nz.co.tumunuiride;

public final class Corridor {
    public static final String NAME = "SH5 Tumunui";
    public static final double A_LAT = -38.180551, A_LON = 176.250324;
    public static final double B_LAT = -38.303871, B_LON = 176.368983;
    public static final int DEFAULT_LIMIT = 100;
    public static final float ENTRY_RADIUS_M = 180f;
    public static final float EXIT_RADIUS_M = 180f;
    private Corridor() {}
}

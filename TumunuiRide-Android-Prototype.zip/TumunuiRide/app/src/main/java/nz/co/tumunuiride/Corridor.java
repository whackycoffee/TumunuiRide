package nz.co.tumunuiride;

public final class Corridor {
    public static final String NAME = "Work Route Test";
    public static final double A_LAT = -37.960450, A_LON = 175.753970;
    public static final double B_LAT = -37.901621, B_LON = 175.772193;
    public static final int DEFAULT_LIMIT = 100;
    public static final float ENTRY_RADIUS_M = 180f;
    public static final float EXIT_RADIUS_M = 180f;
    private Corridor() {}
}

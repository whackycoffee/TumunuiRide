package nz.co.tumunuiride;

import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.location.*;
import android.os.*; import android.speech.tts.TextToSpeech; import androidx.core.app.ActivityCompat; import androidx.core.app.NotificationCompat; import androidx.core.app.NotificationManagerCompat;
import java.util.Locale;

public class RideService extends Service implements LocationListener {
    public static final String ACTION_UPDATE="nz.co.tumunuiride.UPDATE", ACTION_RESET="nz.co.tumunuiride.RESET";
    private final RideEngine engine=new RideEngine(); private LocationManager lm; private TextToSpeech tts;
    private RideState.Phase lastPhase; private int lastWarn=-1;
    @Override public void onCreate(){super.onCreate(); createChannel(); startForeground(7, notification("Monitoring work-route test"));
        tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(Locale.forLanguageTag("en-NZ"));});
        lm=(LocationManager)getSystemService(LOCATION_SERVICE); if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,2,this);
    }
    @Override public int onStartCommand(Intent i,int f,int id){if(i!=null&&ACTION_RESET.equals(i.getAction()))engine.reset();return START_STICKY;}
    @Override public void onLocationChanged(Location l){RideState s=engine.update(l,SystemClock.elapsedRealtime());
        if(s.phase!=lastPhase){if(s.phase==RideState.Phase.IN_ZONE)speak("Average speed zone started. Limit "+s.limitKmh); else if(s.phase==RideState.Phase.COMPLETE)speak("Average speed zone complete");lastPhase=s.phase;}
        if(s.phase==RideState.Phase.IN_ZONE){int w=s.averageKmh>s.limitKmh?2:s.averageKmh>s.limitKmh-3?1:0;if(w!=lastWarn&&w>0)speak(w==2?"Average speed above limit. Reduce speed safely":"Average speed close to limit");lastWarn=w;}
        Intent out=new Intent(ACTION_UPDATE).setPackage(getPackageName());out.putExtra("phase",s.phase.name());out.putExtra("direction",s.direction);out.putExtra("speed",s.speedKmh);out.putExtra("average",s.averageKmh);out.putExtra("remaining",s.distanceToExitM);out.putExtra("progress",s.progress);sendBroadcast(out);
        NotificationManagerCompat.from(this).notify(7,notification(s.phase==RideState.Phase.IN_ZONE?String.format(Locale.NZ,"Average %.1f km/h",s.averageKmh):"Monitoring work-route test"));}
    private void speak(String x){if(tts!=null)tts.speak(x,TextToSpeech.QUEUE_FLUSH,null,"ride");}
    private Notification notification(String text){return new NotificationCompat.Builder(this,"ride").setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("Tumunui Ride").setContentText(text).setOngoing(true).build();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("ride","Ride tracking",NotificationManager.IMPORTANCE_LOW));}
    @Override public void onDestroy(){if(lm!=null)lm.removeUpdates(this);if(tts!=null)tts.shutdown();super.onDestroy();} @Override public android.os.IBinder onBind(Intent i){return null;}
}

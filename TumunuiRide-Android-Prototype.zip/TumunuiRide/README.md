# Tumunui Ride Android prototype

Motorcycle-first section-average display for the SH5 Tumunui corridor.

## Loaded corridor

- Camera A: `-38.180551, 176.250324`
- Camera B: `-38.303871, 176.368983`
- Default permanent limit: 100 km/h (always obey posted/temporary limits)
- Both directions supported

## Build and install

1. Install Android Studio.
2. Open this `TumunuiRide` folder.
3. Allow Android Studio to install SDK 35 and sync Gradle.
4. Connect an Android phone with USB debugging enabled.
5. Select **Run > Run 'app'**.
6. Grant precise location and notification permissions.

The app runs a foreground GPS service, announces zone entry/exit and limit warnings via Android text-to-speech, and keeps tracking with the display locked.

## Prototype limitations

- The live average accumulates filtered GPS distance. Production should map-match readings to SH5 and use an accurately surveyed/road-route distance for the closest camera-equivalent result.
- Entry/exit uses a 180 m geofence plus direction trend. Field testing is required before relying on it.
- GPS readings are estimates and this app provides no protection from spot or mobile enforcement.
- The first build fixes the limit at 100 km/h. Do not use it when a posted or temporary limit differs.

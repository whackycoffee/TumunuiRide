package nz.co.tumunuiride;

import android.location.Location;

public final class RideEngine {
    private final RideState state = new RideState();
    private Location previous;
    private long startElapsed, completedElapsed;
    private double endLat, endLon, corridorM, travelledM;
    private boolean nearExit;

    public RideState update(Location loc, long now) {
        state.speedKmh = loc.hasSpeed() ? Math.max(0, loc.getSpeed() * 3.6) : 0;

        if (state.phase == RideState.Phase.COMPLETE && now - completedElapsed >= 5000) {
            state.phase = RideState.Phase.APPROACHING;
            state.direction = "Monitoring 2 test zones";
            state.zoneName = "";
            state.averageKmh = 0; state.progress = 0; state.distanceToExitM = 0;
        }

        if (state.phase == RideState.Phase.APPROACHING) {
            state.distanceToEntryM = Double.MAX_VALUE;
            if (previous != null && state.speedKmh >= 8) {
                for (Corridor c : Corridor.ALL) {
                    float dA = distance(loc, c.aLat, c.aLon), dB = distance(loc, c.bLat, c.bLon);
                    float oldA = distance(previous, c.aLat, c.aLon), oldB = distance(previous, c.bLat, c.bLon);
                    state.distanceToEntryM = Math.min(state.distanceToEntryM, Math.min(dA, dB));
                    if (dA <= Corridor.ENTRY_RADIUS_M && oldA > dA && dB < oldB) { start(c, true, now); break; }
                    if (dB <= Corridor.ENTRY_RADIUS_M && oldB > dB && dA < oldA) { start(c, false, now); break; }
                }
            }
        } else if (state.phase == RideState.Phase.IN_ZONE) {
            state.elapsedMs = Math.max(1, now - startElapsed);
            state.distanceToExitM = distance(loc, endLat, endLon);
            if (previous != null && loc.getAccuracy() <= 40 && previous.getAccuracy() <= 40) {
                float step = previous.distanceTo(loc);
                if (step < 250) travelledM += step;
            }
            state.progress = Math.min(1, Math.max(travelledM / corridorM, 1 - state.distanceToExitM / corridorM));
            state.averageKmh = (travelledM / (state.elapsedMs / 1000.0)) * 3.6;
            boolean nowNearExit = state.distanceToExitM <= Corridor.EXIT_RADIUS_M;
            if (nearExit && !nowNearExit) {
                state.phase = RideState.Phase.COMPLETE;
                state.direction = state.zoneName + " complete";
                completedElapsed = now;
            }
            nearExit = nowNearExit;
        }
        previous = new Location(loc);
        return state;
    }

    private void start(Corridor c, boolean fromA, long now) {
        double startLat = fromA ? c.aLat : c.bLat, startLon = fromA ? c.aLon : c.bLon;
        endLat = fromA ? c.bLat : c.aLat; endLon = fromA ? c.bLon : c.aLon;
        corridorM = distance(startLat, startLon, endLat, endLon);
        state.zoneName = c.name; state.limitKmh = c.limitKmh;
        state.direction = c.name + (fromA ? "  A → B" : "  B → A");
        state.phase = RideState.Phase.IN_ZONE; startElapsed = now; travelledM = 0;
        state.averageKmh = 0; nearExit = false;
    }

    public void reset() {
        state.phase = RideState.Phase.APPROACHING; state.direction = "Monitoring 2 test zones";
        state.zoneName = ""; state.averageKmh = 0; state.progress = 0; previous = null;
    }
    private static float distance(Location from, double lat, double lon) { return distance(from.getLatitude(), from.getLongitude(), lat, lon); }
    private static float distance(double lat1, double lon1, double lat2, double lon2) {
        float[] out = new float[1]; Location.distanceBetween(lat1, lon1, lat2, lon2, out); return out[0];
    }
}

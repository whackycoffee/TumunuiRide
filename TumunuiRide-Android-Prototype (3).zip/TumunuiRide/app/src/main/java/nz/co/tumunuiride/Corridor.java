package nz.co.tumunuiride;

public final class Corridor {
    public final String name;
    public final double aLat, aLon, bLat, bLon;
    public final int limitKmh;
    public static final float ENTRY_RADIUS_M = 180f;
    public static final float EXIT_RADIUS_M = 180f;

    public static final Corridor[] ALL = {
        new Corridor("Work Route Zone 1", -37.960450, 175.753970, -37.901621, 175.772193, 100),
        new Corridor("Work Route Zone 2", -37.881669, 175.773763, -37.822448, 175.804356, 100)
    };

    public Corridor(String name, double aLat, double aLon, double bLat, double bLon, int limitKmh) {
        this.name = name; this.aLat = aLat; this.aLon = aLon;
        this.bLat = bLat; this.bLon = bLon; this.limitKmh = limitKmh;
    }
}

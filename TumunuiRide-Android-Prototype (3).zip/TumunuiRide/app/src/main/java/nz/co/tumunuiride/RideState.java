package nz.co.tumunuiride;

public final class RideState {
    public enum Phase { APPROACHING, IN_ZONE, COMPLETE }
    public Phase phase = Phase.APPROACHING;
    public String direction = "Waiting for corridor";
    public double speedKmh, averageKmh, distanceToEntryM, distanceToExitM, progress;
    public long elapsedMs;
    public int limitKmh = 100;
    public String zoneName = "";
}
